import sqlite3

class CustomsDeclarationSystem:
    def __init__(self):
        # Connect to SQLite database (creates a new one if it doesn't exist)
        self.connection = sqlite3.connect('customs.db')
        self.cursor = self.connection.cursor()
        self.create_table()

    def create_table(self):
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS Declarations (
                                declaration_id INTEGER PRIMARY KEY AUTOINCREMENT,
                                traveler_name TEXT,
                                item_name TEXT,
                                item_value REAL
                            )''')
        print("Table created successfully or already exists.")

    def insert_declaration(self, traveler_name, item_name, item_value):
        self.cursor.execute(
            "INSERT INTO Declarations (traveler_name, item_name, item_value) VALUES (?, ?, ?)",
            (traveler_name, item_name, item_value)
        )
        self.connection.commit()
        print(f"Declaration inserted: {traveler_name}, {item_name}, {item_value}")

    def read_declaration(self):
        self.cursor.execute("SELECT * FROM Declarations ORDER BY declaration_id DESC LIMIT 5")
        results = self.cursor.fetchall()
        print("Latest Declarations:")
        for row in results:
            print(f"ID: {row[0]}, Traveler: {row[1]}, Item: {row[2]}, Value: ${row[3]}")

    def update_declaration(self, declaration_id, traveler_name=None, item_name=None, item_value=None):
        if traveler_name:
            self.cursor.execute(
                "UPDATE Declarations SET traveler_name = ? WHERE declaration_id = ?",
                (traveler_name, declaration_id)
            )
        if item_name:
            self.cursor.execute(
                "UPDATE Declarations SET item_name = ? WHERE declaration_id = ?",
                (item_name, declaration_id)
            )
        if item_value is not None:  # Ensure item_value is not None
            self.cursor.execute(
                "UPDATE Declarations SET item_value = ? WHERE declaration_id = ?",
                (item_value, declaration_id)
            )
        self.connection.commit()
        print(f"Declaration {declaration_id} updated successfully.")

    def delete_declaration(self, declaration_id):
        self.cursor.execute("DELETE FROM Declarations WHERE declaration_id = ?", (declaration_id,))
        self.connection.commit()
        print(f"Declaration {declaration_id} deleted successfully.")

    def close(self):
        self.cursor.close()
        self.connection.close()

def main_menu():
    system = CustomsDeclarationSystem()

    while True:
        print("\nWelcome to Customs Declaration System")
        print("1. Insert Declaration")
        print("2. Update Declaration")
        print("3. Delete Declaration")
        print("4. Display Latest Declarations and Exit")
        
        choice = input("Enter the process you need to proceed (1-4): ")

        if choice == '1':
            traveler_name = input("Enter traveler's name: ")
            item_name = input("Enter item name: ")
            item_value = float(input("Enter item value: "))
            system.insert_declaration(traveler_name, item_name, item_value)
        elif choice == '2':
            declaration_id = int(input("Enter the declaration ID to update: "))
            traveler_name = input("Enter new traveler's name (or press Enter to skip): ")
            item_name = input("Enter new item name (or press Enter to skip): ")
            item_value_input = input("Enter new item value (or press Enter to skip): ")
            item_value = float(item_value_input) if item_value_input else None  # Convert to float or None
            system.update_declaration(declaration_id, traveler_name, item_name, item_value)
        elif choice == '3':
            declaration_id = int(input("Enter the declaration ID to delete: "))
            system.delete_declaration(declaration_id)
        elif choice == '4':
            system.read_declaration()
            system.close()
            print("Goodbye!")
            break
        else:
            print("Invalid choice, please select a number between 1 and 4.")

if __name__ == "__main__":
    main_menu()